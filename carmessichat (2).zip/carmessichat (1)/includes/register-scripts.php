<?php
function carmessichat_register_assets() {
    // CSS principal
    wp_enqueue_style( 'carmessichat-main', get_template_directory_uri() . '/assets/css/main.css', array(), '1.0' );

    // Librería de iconos (opcional CDN)
    wp_enqueue_style( 'fontawesome-cdn', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css', array(), null );

    // JS principal y cámara
    wp_enqueue_script( 'carmessichat-main-js', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), '1.0', true );
    wp_enqueue_script( 'carmessichat-camera-js', get_template_directory_uri() . '/assets/js/camera.js', array(), '1.0', true );

    // Localize (si necesitas pasar datos PHP a JS)
    wp_localize_script( 'carmessichat-main-js', 'carmessiData', array(
        'ajax_url' => admin_url( 'admin-ajax.php' )
    ) );
}
add_action( 'wp_enqueue_scripts', 'carmessichat_register_assets' );
