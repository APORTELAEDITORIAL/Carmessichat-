<?php
if ( ! function_exists( 'carmessichat_theme_setup' ) ) {
    function carmessichat_theme_setup() {
        add_theme_support( 'title-tag' );
        add_theme_support( 'post-thumbnails' );
        add_image_size( 'carmessi-thumb', 600, 1000, true ); // ejemplo para reels verticales
        register_nav_menus( array(
            'primary' => __( 'Primary Menu', 'carmessichat' ),
        ) );
    }
    add_action( 'after_setup_theme', 'carmessichat_theme_setup' );
}
