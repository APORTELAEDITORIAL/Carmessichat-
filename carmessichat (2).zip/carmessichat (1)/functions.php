<?php
// Seguridad
if ( ! defined('ABSPATH') ) exit;

// Cargar módulos del tema
require_once get_template_directory() . '/inc/setup.php';
require_once get_template_directory() . '/inc/enqueue.php';
require_once get_template_directory() . '/inc/rest-register.php';

/**
 * ============================
 * CPT: Clips y Taxonomía: Hashtags
 * ============================
 */
function carmessichat_register_cpt_clip() {
    $labels = [
        'name' => __('Clips', 'carmessichat'),
        'singular_name' => __('Clip', 'carmessichat'),
    ];
    $args = [
        'labels' => $labels,
        'public' => true,
        'menu_icon' => 'dashicons-video-alt3',
        'supports' => ['title','editor','thumbnail','excerpt','author','comments'],
        'has_archive' => true,
        'rewrite' => ['slug' => 'clips'],
        'show_in_rest' => true,
    ];
    register_post_type('clip', $args);

    // Taxonomía hashtag tipo TikTok (#book, #viral)
    register_taxonomy('hashtag', 'clip', [
        'label' => __('Hashtags', 'carmessichat'),
        'hierarchical' => false,
        'rewrite' => ['slug' => 'hashtag'],
        'show_in_rest' => true,
    ]);
}
add_action('init', 'carmessichat_register_cpt_clip');

/**
 * ============================
 * FOOTER PERSONALIZADO CARMESSICHAT
 * ============================
 * Este footer es puramente visual y NO interfiere con los menús de WordPress.
 */
add_action('wp_footer', function () {
  if ( is_admin() ) return;
  ?>
  <link href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css" rel="stylesheet">

  <style>
  :root{ --gap:16px; --btn:48px; --z-ui:9999; --bar-bg:linear-gradient(90deg,#e51a4c,#b3153b); }
  .app-footer{position:fixed;left:0;right:0;bottom:0;pointer-events:auto;z-index:var(--z-ui);}
  .bottom-bar{position:fixed;left:0;right:0;bottom:8px;display:flex;align-items:center;justify-content:space-around;gap:var(--gap);padding:10px 12px;background:var(--bar-bg);border-radius:20px;margin:0 auto;max-width:560px;box-shadow:0 -4px 12px rgba(0,0,0,.3);color:#fff;}
  .icon-btn,.fab{width:var(--btn);height:var(--btn);border:0;border-radius:999px;background:rgba(255,255,255,.15);display:grid;place-items:center;cursor:pointer;transition:transform .12s ease,box-shadow .12s ease;color:#fff;}
  .fab{width:64px;height:64px;background:#fff;color:#e51a4c;}
  .icon{font-size:24px;line-height:1;}
  </style>

  <footer class="app-footer" role="contentinfo">
    <nav class="bottom-bar" aria-label="Navegación">
      <a id="btn-home" class="icon-btn" href="<?php echo esc_url( home_url('/') ); ?>" aria-label="Inicio"><i class="ri-home-6-line icon"></i></a>
      <button id="btn-vol" class="icon-btn" aria-label="Volumen"><i class="ri-volume-up-line icon"></i></button>
      <button id="btn-create" class="fab" aria-label="Crear" title="Crear"><i class="ri-add-line icon"></i></button>
      <a id="btn-user" class="icon-btn" href="<?php echo esc_url( home_url('/miembros/') ); ?>" aria-label="Perfil"><i class="ri-user-3-line icon"></i></a>
      <a id="btn-msg" class="icon-btn" href="<?php echo esc_url( home_url('/mensajes/') ); ?>" aria-label="Mensajes"><i class="ri-message-3-line icon"></i></a>
    </nav>
  </footer>
  <?php
});
