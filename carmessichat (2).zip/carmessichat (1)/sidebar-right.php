<?php if ( ! defined('ABSPATH') ) exit; ?>
<div class="sidebar-actions">
  <button class="action like" aria-label="Me gusta" title="Me gusta" style="background:#e51a4c;color:#fff;border:0;border-radius:999px;width:44px;height:44px;display:grid;place-items:center;">
    <span>❤</span>
  </button>
  <button class="action comment" aria-label="Comentar" title="Comentar" style="background:#E3000F;color:#fff;border:0;border-radius:999px;width:44px;height:44px;display:grid;place-items:center;">
    <span>💬</span>
  </button>
  <button class="action share" aria-label="Compartir" title="Compartir" style="background:#222;color:#fff;border:0;border-radius:999px;width:44px;height:44px;display:grid;place-items:center;">
    <span>↗</span>
  </button>
</div>


