CarmessiChat – Tema tipo TikTok para WordPress

Tema base para un feed vertical (clips) con colores oficiales #e51a4c y #E3000F.

Requisitos
- WordPress 6+ (preferible)
- PHP 7.4+

Instalación (carpeta)
1. Copia la carpeta del tema a wp-content/themes/carmessichat
2. WP Admin > Apariencia > Temas > Activar “CarmessiChat”

Instalación (ZIP)
1. Comprime la carpeta carmessichat en carmessichat.zip
2. WP Admin > Apariencia > Temas > Añadir nuevo > Subir tema

Incluye
- CPT clip y taxonomía hashtag (editor de bloques)
- Plantillas: single.php, archive.php y template-parts/content-clip.php
- Cabecera con buscador (header.php) y barra lateral derecha (sidebar-right.php)
- Encolado de estilos y scripts (inc/enqueue.php)
- Ruta REST: /wp-json/carmessi/v1/ping

Probar rápido
1. Crea un Clip (Clips > Añadir nuevo) con imagen destacada y hashtags
2. Visita la Home para ver el feed
3. Comprueba /wp-json/carmessi/v1/ping

Estilos y colores
- assets/css/main.css
- --carmessi-primary: #e51a4c
- --carmessi-secondary: #E3000F

Scripts
- assets/js/main.js
- assets/js/floating-sidebar.js
- assets/js/interactions.js

Próximos pasos
- Crear single-clip.php y archive-clip.php dedicados con scroll-snap
- Sustituir emojis por SVG en assets/icons/
- Plantilla taxonomy-hashtag.php para listar por hashtag


