<?php if ( ! defined('ABSPATH') ) exit; ?>
  <?php wp_footer(); ?>
</body>
</html>


