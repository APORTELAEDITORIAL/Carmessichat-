<?php
// Seguridad
if ( ! defined('ABSPATH') ) exit;

function carmessichat_setup_theme_features() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','gallery','caption','comment-list','comment-form','script','style']);

    // Menús
    register_nav_menus([
        'primary' => __('Menú principal', 'carmessichat'),
        'footer'  => __('Menú footer', 'carmessichat'),
    ]);

    // Tamaños de imagen útiles para el feed tipo reels
    add_image_size('carmessi-thumb', 800, 1000, true);
    add_image_size('carmessi-cover', 1200, 1600, true);
}
add_action('after_setup_theme', 'carmessichat_setup_theme_features');



