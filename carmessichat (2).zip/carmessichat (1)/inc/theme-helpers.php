<?php
/**
 * theme-helpers.php
 * Funciones auxiliares reutilizables para el theme MiApp.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Devuelve el SVG inline desde la carpeta svg-icons/.
 * Uso: echo miapp_get_inline_svg('heart');
 *
 * @param string $name Nombre del archivo SVG sin extensión.
 * @return string HTML del SVG o vacio.
 */
function miapp_get_inline_svg( $name ) {
    $file = get_template_directory() . '/svg-icons/' . sanitize_file_name( $name ) . '.svg';
    if ( file_exists( $file ) ) {
        return file_get_contents( $file );
    }
    return '';
}

/**
 * Obtiene la URL del vídeo asociado al post.
 * Supone que guardas la URL en post meta 'miapp_video_url' (plugin o ACF puede crear este meta).
 *
 * @param int|null $post_id
 * @return string|false URL o false si no existe
 */
function miapp_get_video_url( $post_id = null ) {
    $post_id = $post_id ? (int) $post_id : get_the_ID();
    $url = get_post_meta( $post_id, 'miapp_video_url', true );
    if ( $url ) {
        return esc_url( $url );
    }
    // alternativa: usar el attachment featured image/video
    return false;
}

/**
 * Renderiza el markup básico del reproductor de vídeo para un post.
 * Este markup incluye atributos data que el JS necesita.
 *
 * @param int|null $post_id
 * @param array $args Opciones: width, height, poster (opcional)
 * @return void (echo)
 */
function miapp_render_video_player( $post_id = null, $args = array() ) {
    $post_id = $post_id ? (int) $post_id : get_the_ID();
    $video = miapp_get_video_url( $post_id );
    $poster = ! empty( $args['poster'] ) ? esc_url( $args['poster'] ) : get_the_post_thumbnail_url( $post_id, 'large' );
    $autoplay = isset( $args['autoplay'] ) && $args['autoplay'] ? 'autoplay' : '';
    $muted = isset( $args['muted'] ) && $args['muted'] ? 'muted' : 'muted'; // mobile autoplay often requiere muted
    $controls = isset( $args['controls'] ) && $args['controls'] ? 'controls' : '';
    if ( ! $video ) {
        // fallback: si no hay URL, mostrar featured image
        if ( $poster ) {
            echo '<div class="miapp-video-fallback" style="background-image:url('. esc_url( $poster ) .')"></div>';
        }
        return;
    }

    // El video tag con atributos data para JS
    ?>
    <div class="miapp-video-wrapper" data-post-id="<?php echo esc_attr( $post_id ); ?>">
      <video
        class="miapp-video"
        playsinline
        preload="metadata"
        poster="<?php echo esc_attr( $poster ); ?>"
        data-src="<?php echo esc_url( $video ); ?>"
        <?php echo $muted; ?>
        <?php echo $controls; ?>
        width="<?php echo isset($args['width']) ? intval($args['width']) : '360'; ?>"
        height="<?php echo isset($args['height']) ? intval($args['height']) : '640'; ?>"
      >
        <source data-src="<?php echo esc_url( $video ); ?>" type="video/mp4">
        <?php _e( 'Tu navegador no soporta vídeos', 'miapp-theme' ); ?>
      </video>

      <button class="miapp-video-toggle-sound" aria-label="<?php esc_attr_e('Alternar sonido','miapp-theme'); ?>">
        <?php echo miapp_get_inline_svg('icon-sound'); ?>
      </button>

      <button class="miapp-video-playpause" aria-label="<?php esc_attr_e('Reproducir / Pausar','miapp-theme'); ?>">
        <?php echo miapp_get_inline_svg('icon-play'); ?>
      </button>
    </div>
    <?php
}

/**
 * Devuelve un array de hashtags extraídos del contenido (opcional).
 * Puedes usarlo para renderizar listado de hashtags.
 *
 * @param int|null $post_id
 * @return array
 */
function miapp_get_hashtags( $post_id = null ) {
    $post_id = $post_id ? (int) $post_id : get_the_ID();
    $content = get_post_field( 'post_content', $post_id );
    preg_match_all( '/#([A-Za-z0-9_áéíóúñÑ-]+)/u', $content, $matches );
    if ( ! empty( $matches[1] ) ) {
        return array_map( 'sanitize_text_field', $matches[1] );
    }
    return array();
}

/**
 * Helper simple: devuelve número de likes guardado en post meta 'miapp_likes_count'
 * (o calculado desde 'miapp_likes_users')
 */
function miapp_get_likes_count( $post_id = null ) {
    $post_id = $post_id ? (int) $post_id : get_the_ID();
    $users = get_post_meta( $post_id, 'miapp_likes_users', true );
    if ( is_array( $users ) ) {
        return count( $users );
    }
    $count = get_post_meta( $post_id, 'miapp_likes_count', true );
    return intval( $count );
}
