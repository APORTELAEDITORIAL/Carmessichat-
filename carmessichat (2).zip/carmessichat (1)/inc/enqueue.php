<?php
if ( ! defined('ABSPATH') ) exit;

function carmessichat_enqueue_assets() {
    $theme_version = wp_get_theme()->get('Version');

    // CSS base
    wp_enqueue_style('carmessi-main', get_template_directory_uri() . '/assets/css/main.css', [], $theme_version);

    // JS principal (para interacciones básicas del tema)
    wp_enqueue_script('carmessi-main-js', get_template_directory_uri() . '/assets/js/main.js', ['jquery'], $theme_version, true);

    // Sidebar flotante y micro-interacciones
    wp_enqueue_script('carmessi-floating-sidebar', get_template_directory_uri() . '/assets/js/floating-sidebar.js', [], $theme_version, true);
    wp_enqueue_script('carmessi-interactions', get_template_directory_uri() . '/assets/js/interactions.js', [], $theme_version, true);

    // Feed ajax + infinite scroll
    wp_enqueue_script('carmessi-feed-ajax', get_template_directory_uri() . '/assets/js/feed-ajax.js', [], $theme_version, true);
    wp_enqueue_script('carmessi-infinite-scroll', get_template_directory_uri() . '/assets/js/infinite-scroll.js', ['carmessi-feed-ajax'], $theme_version, true);
}
add_action('wp_enqueue_scripts', 'carmessichat_enqueue_assets');



