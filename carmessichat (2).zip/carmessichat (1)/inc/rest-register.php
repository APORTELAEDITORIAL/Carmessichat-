<?php
if ( ! defined('ABSPATH') ) exit;

// Rutas REST básicas del tema (de prueba y base para extender)
add_action('rest_api_init', function(){
    register_rest_route('carmessi/v1', '/ping', [
        'methods'  => 'GET',
        'callback' => function(){
            return [
                'ok' => true,
                'time' => time(),
                'site' => get_bloginfo('name'),
            ];
        },
        'permission_callback' => '__return_true',
    ]);
});


