// interactions.js
window.addEventListener('DOMContentLoaded', () => {
  // Like simple
  document.body.addEventListener('click', (e) => {
    const btn = e.target.closest('.sidebar-right .action.like');
    if (!btn) return;
    btn.classList.toggle('on');
  });

  // Auto play/pause en viewport (si usas <video>)
  const videos = document.querySelectorAll('video[autoplay]');
  if (videos.length) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        const v = entry.target;
        if (entry.isIntersecting) {
          v.play().catch(()=>{});
        } else {
          v.pause();
        }
      });
    }, { threshold: 0.6 });

    videos.forEach(v => io.observe(v));
  }
});


