// feed-ajax.js – carga de clips por REST API (wp/v2/clip)
(function(){
  const FEED_SELECTOR = '.feed';
  const PER_PAGE = 6;

  function ensureSentinel() {
    const feed = document.querySelector(FEED_SELECTOR);
    if (!feed) return null;
    let sentinel = document.getElementById('feed-sentinel');
    if (!sentinel) {
      sentinel = document.createElement('div');
      sentinel.id = 'feed-sentinel';
      sentinel.style.height = '1px';
      sentinel.style.width = '100%';
      feed.appendChild(sentinel);
    }
    return sentinel;
  }

  async function fetchClips(page){
    const base = (window.wpApiSettings && window.wpApiSettings.root) ? window.wpApiSettings.root : `${location.origin}/wp-json/`;
    const url = `${base}wp/v2/clip?per_page=${PER_PAGE}&page=${page}&_embed=1`;
    const res = await fetch(url);
    if (!res.ok) return { items: [], done: true };
    const items = await res.json();
    const totalPages = parseInt(res.headers.get('X-WP-TotalPages') || '1', 10);
    return { items, done: page >= totalPages };
  }

  function renderClip(post){
    const title = post.title && post.title.rendered ? post.title.rendered : '';
    const link = post.link;
    const media = post._embedded && post._embedded['wp:featuredmedia'] && post._embedded['wp:featuredmedia'][0];
    const thumb = media && media.media_details && media.media_details.sizes && (media.media_details.sizes.medium_large || media.media_details.sizes.full);
    const img = thumb ? thumb.source_url : '';

    const article = document.createElement('article');
    article.className = 'feed-item';
    article.innerHTML = `
      ${img ? `<div class="feed-image"><img src="${img}" alt="${title.replace(/"/g,'&quot;')}"></div>` : ''}
      <h2 class="feed-title">${title}</h2>
      <a class="feed-button" href="${link}">Ver más</a>
    `;
    return article;
  }

  function appendClips(posts){
    const feed = document.querySelector(FEED_SELECTOR);
    if (!feed) return;
    posts.forEach(p => feed.insertBefore(renderClip(p), document.getElementById('feed-sentinel')));
  }

  // Expose a tiny loader used by infinite-scroll.js
  window.CarmessiFeed = window.CarmessiFeed || {
    page: 1,
    loading: false,
    done: false,
    async loadNext(){
      if (this.loading || this.done) return;
      this.loading = true;
      try {
        this.page += 1;
        const { items, done } = await fetchClips(this.page);
        appendClips(items);
        this.done = done;
      } catch(e) {
        console.warn('feed-ajax error', e);
        this.done = true;
      } finally {
        this.loading = false;
      }
    }
  };

  // Prepare sentinel once DOM is ready
  window.addEventListener('DOMContentLoaded', ensureSentinel);
})();


