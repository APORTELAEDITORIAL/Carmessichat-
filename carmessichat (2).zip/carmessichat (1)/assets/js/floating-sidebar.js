// floating-sidebar.js
window.addEventListener('DOMContentLoaded', () => {
  const sidebar = document.querySelector('.floating-sidebar');
  if (!sidebar) return;

  // Resalta el item activo según la URL
  const links = sidebar.querySelectorAll('a[href]');
  links.forEach(link => {
    if (location.pathname === new URL(link.href).pathname) {
      link.classList.add('is-active');
    }
  });
});


