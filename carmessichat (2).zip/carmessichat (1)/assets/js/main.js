// main.js - interacción básica
jQuery(document).ready(function($){
  console.log('CarmessiChat theme activo');

  // Abrir la cámara cuando el usuario pulse el botón central
  $('#openCamera').on('click', function(e){
    e.preventDefault();
    // Disparamos evento global; camera.js escucha este evento
    const event = new Event('carmessi_open_camera');
    window.dispatchEvent(event);
  });
});
