/**
 * video-player.js
 * Controla autoplay, lazy-load, marcación de vistas y gestos (double-tap) para vídeos del feed.
 *
 * Requisitos:
 * - Que el theme encole este archivo (wp_enqueue_script).
 * - Que el theme pase MiAppData.rest_url y MiAppData.nonce (wp_localize_script).
 * - Que cada vídeo esté envuelto en .miapp-video-wrapper con data-post-id y contenga <video class="miapp-video">.
 *
 * Ejemplo de markup esperado:
 * <div class="miapp-video-wrapper" data-post-id="123">
 *   <video class="miapp-video" playsinline preload="metadata" poster="..." data-src="https://.../video.mp4">
 *     <source data-src="https://.../video.mp4" type="video/mp4">
 *   </video>
 *   <button class="miapp-video-toggle-sound">...</button>
 *   <button class="miapp-video-playpause">...</button>
 * </div>
 */

( function () {
    'use strict';
  
    // -----------------------
    // Utilidades
    // -----------------------
    function safeMiAppData() {
      return (typeof MiAppData !== 'undefined') ? MiAppData : { rest_url: '/wp-json/miapp/v1/', nonce: '' };
    }
  
    // wrapper fetch con nonce y manejo básico de errores
    async function miappFetch(endpoint, payload = {}) {
      const cfg = safeMiAppData();
      const url = cfg.rest_url.replace(/\/?$/, '/') + endpoint.replace(/^\/?/, '');
      const opts = {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': cfg.nonce
        },
        body: JSON.stringify(payload)
      };
      const resp = await fetch(url, opts);
      // intenta parsear JSON, pero maneja error
      if (!resp.ok) {
        const txt = await resp.text();
        throw new Error('HTTP ' + resp.status + ' — ' + txt);
      }
      const json = await resp.json();
      return json;
    }
  
    // -----------------------
    // Marca vista (una sola por post en esta sesión)
    // -----------------------
    const viewedPosts = new Set();
    function markViewOnce(postId) {
      if (!postId || viewedPosts.has(postId)) return;
      viewedPosts.add(postId);
      // fire-and-forget; no bloquea UX
      miappFetch('view', { post_id: postId }).catch(err => {
        // opcional: revertir set si quieres reintentar en otra sesión
        console.warn('miapp:view error', err);
      });
    }
  
    // -----------------------
    // Inicialización del reproductor
    // -----------------------
    function initVideoPlayers() {
      const wrappers = Array.from(document.querySelectorAll('.miapp-video-wrapper'));
  
      if (!wrappers.length) return;
  
      // IntersectionObserver: reproducir cuando al menos 50% visible
      const io = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          const wrapper = entry.target;
          const video = wrapper.querySelector('video.miapp-video');
          if (!video) return;
  
          if (entry.intersectionRatio >= 0.5) {
            // lazy load: asignar src si está en data-src
            const source = video.querySelector('source');
            const dataSrc = (source && !source.src) ? (source.getAttribute('data-src') || video.getAttribute('data-src')) : null;
            if (dataSrc) {
              source.src = dataSrc;
              // algunos navegadores requieren setear video.src también
              if (!video.getAttribute('src')) video.setAttribute('src', dataSrc);
              video.load();
            }
  
            // intentar reproducir (autoplay puede fallar si no está muted)
            video.play().catch(() => { /* no molestar al usuario si falla autoplay */ });
  
            // marcar vista
            const postId = wrapper.dataset.postId;
            markViewOnce(postId);
  
          } else {
            // fuera del umbral: pausar
            video.pause();
          }
        });
      }, { threshold: [0.5] });
  
      // Configuraciones y listeners por wrapper
      wrappers.forEach(wrapper => {
        const video = wrapper.querySelector('video.miapp-video');
        if (!video) return;
  
        // Observa el wrapper
        io.observe(wrapper);
  
        // Botón toggle sonido
        const btnSound = wrapper.querySelector('.miapp-video-toggle-sound');
        if (btnSound) {
          btnSound.addEventListener('click', function (e) {
            e.preventDefault();
            video.muted = !video.muted;
            wrapper.classList.toggle('is-muted', video.muted);
            // Si quieres, cambia icono en btnSound aquí
          });
        }
  
        // Botón play/pause
        const btnPlay = wrapper.querySelector('.miapp-video-playpause');
        if (btnPlay) {
          btnPlay.addEventListener('click', function (e) {
            e.preventDefault();
            if (video.paused) {
              video.play().catch(()=>{});
              wrapper.classList.remove('is-paused');
            } else {
              video.pause();
              wrapper.classList.add('is-paused');
            }
          });
        }
  
        // Doble tap en móviles -> disparar evento para Like
        let lastTap = 0;
        wrapper.addEventListener('touchend', function (ev) {
          const current = Date.now();
          const delta = current - lastTap;
          if (delta > 0 && delta < 300) {
            const postId = wrapper.dataset.postId;
            // evento custom para que otro script (like handler) lo capte
            const dbl = new CustomEvent('miapp:dbltap', { detail: { postId } });
            wrapper.dispatchEvent(dbl);
          }
          lastTap = current;
        });
  
        // Listener por si otro script quiere reaccionar al dbltap (por si quieres animación)
        wrapper.addEventListener('miapp:dbltap', function (e) {
          // por defecto simulamos click al botón like dentro del wrapper
          const likeBtn = wrapper.querySelector('.miapp-action.miapp-like');
          if (likeBtn) likeBtn.click();
        });
  
        // Pausar/reanudar si el usuario interacciona con controles nativos
        video.addEventListener('play', () => wrapper.classList.remove('is-paused'));
        video.addEventListener('pause', () => wrapper.classList.add('is-paused'));
  
        // Manejo simple de errores
        video.addEventListener('error', (err) => {
          console.warn('Video error', err);
        });
      });
    }
  
    // -----------------------
    // Inicializar cuando DOM esté listo
    // -----------------------
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initVideoPlayers);
    } else {
      initVideoPlayers();
    }
  
  })();
  