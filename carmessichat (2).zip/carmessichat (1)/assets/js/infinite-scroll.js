y// infinite-scroll.js – usa IntersectionObserver y CarmessiFeed.loadNext()
(function(){
  let observer;
  function init(){
    const sentinel = document.getElementById('feed-sentinel');
    if (!sentinel || !window.CarmessiFeed) return;

    observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          window.CarmessiFeed.loadNext();
        }
      });
    }, { rootMargin: '200px 0px', threshold: 0.01 });

    observer.observe(sentinel);
  }

  window.addEventListener('DOMContentLoaded', init);
})();


