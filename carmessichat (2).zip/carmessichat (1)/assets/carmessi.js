/* ===== CarmessiChat JS (final) ===== */
console.log('[Carmessi] JS cargado');

function carmessiGetVisibleVideo() {
  const vids = Array.from(document.querySelectorAll('.carmessi-feed video'));
  if (!vids.length) return null;
  const vh = window.innerHeight;
  let best = null, bestArea = 0;
  vids.forEach(v => {
    const r = v.getBoundingClientRect();
    const area = Math.max(0, Math.min(vh, r.bottom) - Math.max(0, r.top)) * Math.max(0, r.right - r.left);
    if (area > bestArea) { bestArea = area; best = v; }
  });
  return best || vids[0];
}
function toggleIcon(el, lineClass, fillClass, active) {
  if (!el) return;
  const i = el.querySelector('i'); if (!i) return;
  i.classList.remove(active ? lineClass : fillClass);
  i.classList.add(active ? fillClass : lineClass);
  el.classList.toggle('active', !!active);
}
function localKey(suffix){ return location.pathname + '#' + suffix; }
function localGet(k, def){ try{ return JSON.parse(localStorage.getItem(k)) ?? def; }catch(e){ return def; } }
function localSet(k, v){ localStorage.setItem(k, JSON.stringify(v)); }

/* autoplay (si hay videos) */
(function(){
  const playOnlyVisible = () => {
    const vids = Array.from(document.querySelectorAll('.carmessi-feed video'));
    const vh = window.innerHeight;
    vids.forEach(v => {
      const r = v.getBoundingClientRect();
      const inView = r.top < vh*0.6 && r.bottom > vh*0.4;
      if (inView) { v.muted = true; v.loop = true; v.play().catch(()=>{}); }
      else { v.pause(); }
    });
  };
  document.addEventListener('scroll', playOnlyVisible, {passive:true});
  window.addEventListener('resize', playOnlyVisible);
  window.addEventListener('load', playOnlyVisible);
})();

/* UI */
window.addEventListener('load', () => {
  const $ = id => document.getElementById(id);
  const btnLike     = $('btn-like');
  const btnBookmark = $('btn-bookmark');
  const btnUp       = $('btn-up');
  const btnDown     = $('btn-down');
  const btnVol      = $('btn-vol');
  const btnComments = $('btn-comments');

  function bumpCount(btn, dir){
    const el = btn && btn.querySelector('.count');
    if (!el) return;
    const n = parseInt(el.textContent || '0', 10) || 0;
    el.textContent = Math.max(0, n + dir);
  }

  const k = localKey('state');
  let state = localGet(k, { liked:false, bookmarked:false, vote:0 });

  toggleIcon(btnLike, 'ri-heart-3-line', 'ri-heart-3-fill', state.liked);
  toggleIcon(btnBookmark, 'ri-bookmark-line', 'ri-bookmark-fill', state.bookmarked);
  toggleIcon(btnUp, 'ri-thumb-up-line', 'ri-thumb-up-fill', state.vote === 1);
  toggleIcon(btnDown, 'ri-thumb-down-line', 'ri-thumb-down-fill', state.vote === -1);

  if (btnLike) btnLike.addEventListener('click', () => {
    const next = !state.liked;
    toggleIcon(btnLike, 'ri-heart-3-line', 'ri-heart-3-fill', next);
    bumpCount(btnLike, next ? +1 : -1);
    state.liked = next; localSet(k, state);
    console.log('[Carmessi] like', next);
  });

  if (btnBookmark) btnBookmark.addEventListener('click', () => {
    const next = !state.bookmarked;
    toggleIcon(btnBookmark, 'ri-bookmark-line', 'ri-bookmark-fill', next);
    state.bookmarked = next; localSet(k, state);
    console.log('[Carmessi] bookmark', next);
  });

  if (btnUp) btnUp.addEventListener('click', () => {
    state.vote = state.vote === 1 ? 0 : 1;
    toggleIcon(btnUp, 'ri-thumb-up-line', 'ri-thumb-up-fill', state.vote === 1);
    toggleIcon(btnDown, 'ri-thumb-down-line', 'ri-thumb-down-fill', state.vote === -1);
    localSet(k, state);
    console.log('[Carmessi] vote', state.vote);
  });
  if (btnDown) btnDown.addEventListener('click', () => {
    state.vote = state.vote === -1 ? 0 : -1;
    toggleIcon(btnUp, 'ri-thumb-up-line', 'ri-thumb-up-fill', state.vote === 1);
    toggleIcon(btnDown, 'ri-thumb-down-line', 'ri-thumb-down-fill', state.vote === -1);
    localSet(k, state);
    console.log('[Carmessi] vote', state.vote);
  });

  if (btnVol) btnVol.addEventListener('click', () => {
    const v = carmessiGetVisibleVideo();
    if (v) {
      v.muted = !v.muted;
      const i = btnVol.querySelector('i');
      i.classList.toggle('ri-volume-up-line', !v.muted);
      i.classList.toggle('ri-volume-mute-line', v.muted);
    }
    console.log('[Carmessi] mute toggle');
  });

  if (btnComments) btnComments.addEventListener('click', () => {
    let panel = document.querySelector('#carmessi-comments');
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'carmessi-comments';
      panel.style.cssText = 'position:fixed;inset:auto 0 0 0;background:#fff;max-height:60vh;border-radius:16px 16px 0 0;box-shadow:0 -8px 30px rgba(0,0,0,.4);padding:12px;z-index:10000;overflow:auto;';
      panel.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;"><strong>Comentarios</strong><button id="carmessi-close" class="icon-btn" style="background:#eee;color:#333;border-radius:8px;padding:6px 10px">Cerrar</button></div><p style="color:#555;margin:8px 0 0">Pronto aquí irán los comentarios…</p>';
      document.body.appendChild(panel);
      document.getElementById('carmessi-close').onclick = () => panel.remove();
    }
    console.log('[Carmessi] open comments');
  });

  console.log('[Carmessi] Listeners OK');
});
