<?php get_header(); ?>

<main class="feed-container">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <?php if (get_post_type() === 'clip') : ?>
      <?php get_template_part('template-parts/content', 'clip'); ?>
    <?php else : ?>
      <article class="feed-item">
        <?php if (has_post_thumbnail()) : ?>
          <div class="feed-image"><?php the_post_thumbnail('large'); ?></div>
        <?php endif; ?>
        <h1 class="feed-title"><?php the_title(); ?></h1>
        <div class="feed-content"><?php the_content(); ?></div>
      </article>
    <?php endif; ?>
  <?php endwhile; endif; ?>
</main>

<?php get_footer(); ?>



