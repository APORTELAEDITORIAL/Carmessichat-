<?php if ( ! defined('ABSPATH') ) exit; ?>
<form role="search" method="get" class="carmessi-search" action="<?php echo esc_url( home_url('/') ); ?>" style="flex:1;">
  <label class="screen-reader-text" for="s">Buscar:</label>
  <input type="search" id="s" name="s" value="<?php echo get_search_query(); ?>" placeholder="Buscar clips, hashtags o usuarios"
    style="width:100%;padding:10px 14px;border-radius:999px;border:1px solid rgba(255,255,255,.1);background:#1a1a1a;color:#fff;outline:none;" />
</form>


