<?php
// Plantilla para un Clip individual en feed estilo TikTok
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('carmessi-clip'); ?> style="padding:20px; border-bottom:1px solid rgba(255,255,255,0.06);">
  <header style="display:flex;align-items:center;gap:10px;">
    <div style="font-weight:700;">@<?php echo esc_html( get_the_author_meta('user_nicename') ); ?></div>
    <div style="color:#f5a; font-size:12px;">
      <?php the_terms(get_the_ID(), 'hashtag', '#', ' #'); ?>
    </div>
  </header>

  <div class="clip-media" style="margin-top:12px;">
    <?php if ( has_post_thumbnail() ) { the_post_thumbnail('carmessi-cover'); } ?>
  </div>

  <div class="clip-caption" style="margin-top:10px;">
    <h2 style="margin:0 0 6px;font-size:18px;line-height:1.2;">
      <?php the_title(); ?>
    </h2>
    <div style="color:#ddd; font-size:14px;">
      <?php the_excerpt(); ?>
    </div>
  </div>
</article>



