<?php
// Si quieres usar [carmessi_camera] que cargue la cámara en una página
?>
<div class="carmessi-camera-page">
  <h2> cámara carnessi </h2>
  <p>Pulsa el botón de la barra inferior para abrir la cámara.</p>
</div>
