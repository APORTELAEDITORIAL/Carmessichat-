<?php
// Un diseño muy simple para un post (reel)
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('carmessi-reel'); ?> style="padding:20px; border-bottom:1px solid rgba(255,255,255,0.04);">
  <div class="reel-media">
    <?php if ( has_post_thumbnail() ) {
      the_post_thumbnail('carmessi-thumb');
    } ?>
  </div>
  <div class="reel-meta" style="margin-top:10px;">
    <h2 style="margin:0; font-size:16px;"><?php the_title(); ?></h2>
    <p style="margin:6px 0 0; color:#ccc;"><?php the_excerpt(); ?></p>
  </div>
</article>
