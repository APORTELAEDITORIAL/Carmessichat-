<?php
// Base de plantilla de perfil: personalízalo más tarde
?>
<section class="carmessi-profile" style="padding:20px;">
  <h2><?php echo esc_html( get_the_author() ); ?></h2>
  <p>Perfil básico</p>
</section>
