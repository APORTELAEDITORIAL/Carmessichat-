<?php
/* 
Template Name: Carmessi Feed
Template Post Type: page
*/
defined('ABSPATH') || exit;

get_header(); ?>

<main class="carmessi-feed" role="main">
  <?php
  // Últimas entradas como clips
  $q = new WP_Query([
    'post_type'      => 'post',
    'posts_per_page' => 20,
    'orderby'        => 'date',
    'order'          => 'DESC',
    'ignore_sticky_posts' => true,
  ]);

  if ( $q->have_posts() ):
    while ( $q->have_posts() ): $q->the_post(); ?>
      <article <?php post_class('clip'); ?>>
        <div class="clip-media">
          <?php the_content(); // bloque Video del editor ?>
        </div>
        <div class="clip-caption">
          <div class="clip-author"><?php the_author(); ?></div>
          <div class="clip-excerpt"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></div>
        </div>
      </article>
    <?php endwhile;
    wp_reset_postdata();
  else:
    echo '<p style="color:#fff">No hay clips aún.</p>';
  endif;
  ?>
</main>

<?php get_footer();
