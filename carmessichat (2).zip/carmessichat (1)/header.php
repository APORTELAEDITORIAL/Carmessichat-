<?php if ( ! defined('ABSPATH') ) exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
  <header class="carmessi-header" style="position:sticky;top:0;z-index:1000;background:#111;border-bottom:1px solid rgba(255,255,255,.06);">
    <div class="wrap" style="display:flex;align-items:center;gap:12px;padding:10px 14px;">
      <a href="<?php echo esc_url( home_url('/') ); ?>" class="brand" style="color:#fff;text-decoration:none;font-weight:700;">CarmessiChat</a>
      <?php get_template_part('template-parts/header/searchbar'); ?>
    </div>
  </header>

  <aside class="sidebar-right" aria-label="Acciones" style="position:fixed;right:10px;bottom:90px;display:flex;flex-direction:column;gap:14px;align-items:center;">
    <?php get_sidebar('right'); ?>
  </aside>


