<?php get_header(); ?>

<main class="feed-container">
  <section class="feed">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <article class="feed-item">
        <?php if (has_post_thumbnail()) : ?>
          <div class="feed-image"><?php the_post_thumbnail('large'); ?></div>
        <?php endif; ?>
        <h2 class="feed-title"><?php the_title(); ?></h2>
        <div class="feed-content"><?php the_excerpt(); ?></div>
        <a href="<?php the_permalink(); ?>" class="feed-button">Ver más</a>
      </article>
    <?php endwhile; else : ?>
      <p>No hay publicaciones disponibles aún.</p>
    <?php endif; ?>
  </section>
</main>

<?php get_footer(); ?>
